package userinterface;

public interface UserInterface {
    public abstract void update(String theMessage);    
}
